# Kindred — Donation Item Inventory

A responsive donation and distribution tracker built with Flask, Bootstrap 5, vanilla JavaScript, JSON, CSV, and Chart.js. The application stores records locally in `data/inventory.json` and creates a starter dataset the first time it runs.

## Features

- Dashboard with donated, distributed, available, and low-stock totals.
- Chart of available stock by category and recent donation/distribution activity.
- Donation intake with server-side and browser-side validation.
- Inventory totals, category filtering, search, stock adjustments, and low-stock status.
- Distribution tracking that prevents issuing more stock than is available.
- CSV download containing donation, distribution, and adjustment records.
- Persistent, human-readable JSON storage with atomic file replacement.
- Responsive layouts for desktop and mobile screens.
- 40 sample donation records and 8 sample distributions on a fresh install.

## Project structure

```text
.
├── app.py
├── requirements.txt
├── README.md
├── data/
│   └── inventory.json       # Created on first run; persistent local data
├── static/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── app.js
└── templates/
    ├── base.html
    ├── dashboard.html
    ├── donations.html
    ├── distributions.html
    ├── error.html
    └── inventory.html
```

## Run locally

Python 3.9 or newer is recommended.

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

Open [http://127.0.0.1:5000](http://127.0.0.1:5000). To use the exact two-command setup after dependencies are installed:

```powershell
pip install -r requirements.txt
python app.py
```

The first launch creates `data/inventory.json` with sample records. Subsequent launches reuse that file and preserve changes. Back up the JSON file to back up your data.

## Data and validation

Donation and distribution quantities must be positive whole numbers. Dates must be valid and cannot be in the future. Distribution quantities are checked against current stock. Inventory adjustments may add or remove stock, but cannot take available inventory below zero. Low stock means an item's available quantity is at or below 10 units.

CSV export is available using the **Export CSV** link in the navigation. The export includes all donation, distribution, and adjustment records.

## Configuration

- `FLASK_SECRET_KEY`: set a private key for Flask flash-message sessions in deployed environments.
- `FLASK_DEBUG=1`: enables Flask debug mode for local development only.

This JSON-backed app is intended for local use or a single application process. For multi-user production deployments, use a database and configure a production WSGI server.
