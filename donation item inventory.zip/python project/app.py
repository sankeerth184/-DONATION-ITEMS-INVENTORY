import csv
import io
import json
import os
import tempfile
import threading
import uuid
from collections import defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path

from flask import Flask, flash, make_response, redirect, render_template, request, url_for


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_FILE = DATA_DIR / "inventory.json"
LOW_STOCK_THRESHOLD = 10
STORE_LOCK = threading.RLock()

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("FLASK_SECRET_KEY", "local-development-key")


def _sample_store():
    """Create predictable starter data for a first-time installation."""
    items = [
        ("Rice", "Food", "kg"),
        ("Canned vegetables", "Food", "cans"),
        ("Blankets", "Shelter", "pieces"),
        ("Winter coats", "Clothing", "pieces"),
        ("First-aid kits", "Medical", "kits"),
        ("Soap bars", "Hygiene", "bars"),
        ("Bottled water", "Water", "bottles"),
        ("School notebooks", "Education", "pieces"),
        ("Baby formula", "Food", "tins"),
        ("Sleeping bags", "Shelter", "pieces"),
    ]
    donations = []
    today = date.today()
    for index in range(40):
        item, category, unit = items[index % len(items)]
        donations.append(
            {
                "id": f"seed-donation-{index + 1:03d}",
                "item": item,
                "category": category,
                "unit": unit,
                "quantity": [12, 18, 24, 30, 8][index % 5],
                "donor": [
                    "Community Center",
                    "Northside Market",
                    "Riverbend Foundation",
                    "Local Volunteers",
                    "Anonymous donor",
                ][index % 5],
                "date": (today - timedelta(days=(index * 3) % 90)).isoformat(),
                "notes": "Sample donation",
                "created_at": datetime.now().isoformat(timespec="seconds"),
            }
        )

    distributions = []
    for index, item_index in enumerate([0, 1, 2, 3, 4, 5, 6, 8]):
        item, _, _ = items[item_index]
        distributions.append(
            {
                "id": f"seed-distribution-{index + 1:03d}",
                "item": item,
                "quantity": 4 + (index % 3) * 2,
                "recipient": [
                    "Maple Street Shelter",
                    "Hope Family Services",
                    "Eastside Community Pantry",
                    "Harbor Outreach",
                ][index % 4],
                "date": (today - timedelta(days=index * 4 + 1)).isoformat(),
                "notes": "Sample distribution",
                "created_at": datetime.now().isoformat(timespec="seconds"),
            }
        )
    return {"donations": donations, "distributions": distributions, "adjustments": []}


def load_store():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not DATA_FILE.exists():
        save_store(_sample_store())
    with STORE_LOCK:
        try:
            with DATA_FILE.open("r", encoding="utf-8") as file:
                store = json.load(file)
        except (OSError, json.JSONDecodeError) as error:
            raise RuntimeError(f"Unable to read inventory data at {DATA_FILE}: {error}") from error
    for key in ("donations", "distributions", "adjustments"):
        if key not in store or not isinstance(store[key], list):
            raise RuntimeError(f"Inventory data is invalid: '{key}' must be a list.")
    return store


def save_store(store):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with STORE_LOCK:
        temporary_path = None
        try:
            with tempfile.NamedTemporaryFile(
                "w", encoding="utf-8", dir=DATA_DIR, delete=False, suffix=".tmp"
            ) as file:
                json.dump(store, file, indent=2, ensure_ascii=False)
                file.write("\n")
                temporary_path = file.name
            os.replace(temporary_path, DATA_FILE)
        except OSError as error:
            if temporary_path and os.path.exists(temporary_path):
                os.unlink(temporary_path)
            raise RuntimeError(f"Unable to save inventory data at {DATA_FILE}: {error}") from error


def inventory_summary(store):
    items = {}
    for donation in store["donations"]:
        key = donation["item"].casefold()
        entry = items.setdefault(
            key,
            {
                "item": donation["item"],
                "category": donation["category"],
                "unit": donation["unit"],
                "donated": 0,
                "distributed": 0,
                "adjustments": 0,
            },
        )
        entry["donated"] += donation["quantity"]
    for adjustment in store["adjustments"]:
        key = adjustment["item"].casefold()
        entry = items.setdefault(
            key,
            {
                "item": adjustment["item"],
                "category": adjustment["category"],
                "unit": adjustment["unit"],
                "donated": 0,
                "distributed": 0,
                "adjustments": 0,
            },
        )
        entry["adjustments"] += adjustment["quantity"]
    for distribution in store["distributions"]:
        key = distribution["item"].casefold()
        entry = items.get(key)
        if entry:
            entry["distributed"] += distribution["quantity"]
    for entry in items.values():
        entry["available"] = entry["donated"] + entry["adjustments"] - entry["distributed"]
        entry["low_stock"] = entry["available"] <= LOW_STOCK_THRESHOLD
    return sorted(items.values(), key=lambda entry: entry["item"].casefold())


def _form_text(field, label, maximum=80):
    value = request.form.get(field, "").strip()
    if not value:
        raise ValueError(f"{label} is required.")
    if len(value) > maximum:
        raise ValueError(f"{label} must be {maximum} characters or fewer.")
    return value


def _form_quantity(allow_negative=False):
    raw_quantity = request.form.get("quantity", "").strip()
    try:
        quantity = int(raw_quantity)
    except ValueError as error:
        raise ValueError("Quantity must be a whole number.") from error
    if quantity == 0 or (quantity < 0 and not allow_negative):
        raise ValueError("Quantity must be greater than zero.")
    if abs(quantity) > 100000:
        raise ValueError("Quantity cannot exceed 100,000.")
    return quantity


def _form_date():
    value = request.form.get("date", "").strip()
    try:
        parsed_date = date.fromisoformat(value)
    except ValueError as error:
        raise ValueError("Enter a valid date.") from error
    if parsed_date > date.today():
        raise ValueError("Date cannot be in the future.")
    return value


def _new_id():
    return str(uuid.uuid4())


@app.context_processor
def inject_globals():
    return {"low_stock_threshold": LOW_STOCK_THRESHOLD, "today": date.today().isoformat()}


@app.route("/")
def dashboard():
    store = load_store()
    inventory = inventory_summary(store)
    total_donated = sum(row["quantity"] for row in store["donations"])
    total_distributed = sum(row["quantity"] for row in store["distributions"])
    recent_activity = sorted(
        [
            dict(row, activity_type="Donation")
            for row in store["donations"]
        ]
        + [
            dict(row, activity_type="Distribution")
            for row in store["distributions"]
        ],
        key=lambda row: (row["date"], row["created_at"]),
        reverse=True,
    )[:8]
    categories = defaultdict(int)
    for item in inventory:
        categories[item["category"]] += item["available"]
    return render_template(
        "dashboard.html",
        inventory=inventory,
        recent_activity=recent_activity,
        total_donated=total_donated,
        total_distributed=total_distributed,
        total_available=total_donated + sum(row["quantity"] for row in store["adjustments"]) - total_distributed,
        low_stock_items=[item for item in inventory if item["low_stock"]],
        category_labels=list(categories.keys()),
        category_values=list(categories.values()),
    )


@app.route("/donations", methods=["GET", "POST"])
def donations():
    if request.method == "POST":
        try:
            item = _form_text("item", "Item name")
            category = _form_text("category", "Category", 40)
            unit = _form_text("unit", "Unit", 24)
            donor = _form_text("donor", "Donor", 80)
            notes = request.form.get("notes", "").strip()
            if len(notes) > 500:
                raise ValueError("Notes must be 500 characters or fewer.")
            record = {
                "id": _new_id(),
                "item": item,
                "category": category,
                "unit": unit,
                "quantity": _form_quantity(),
                "donor": donor,
                "date": _form_date(),
                "notes": notes,
                "created_at": datetime.now().isoformat(timespec="seconds"),
            }
            store = load_store()
            store["donations"].append(record)
            save_store(store)
            flash(f"{record['quantity']} {unit} of {item} added to inventory.", "success")
            return redirect(url_for("donations"))
        except ValueError as error:
            flash(str(error), "danger")
    store = load_store()
    query = request.args.get("q", "").strip().casefold()
    records = [
        row for row in store["donations"]
        if not query or query in " ".join(
            str(row.get(key, "")) for key in ("item", "category", "donor", "notes")
        ).casefold()
    ]
    records.sort(key=lambda row: (row["date"], row["created_at"]), reverse=True)
    return render_template("donations.html", donations=records, query=request.args.get("q", ""))


@app.route("/inventory", methods=["GET", "POST"])
def inventory():
    if request.method == "POST":
        try:
            item = _form_text("item", "Item name")
            category = _form_text("category", "Category", 40)
            unit = _form_text("unit", "Unit", 24)
            quantity = _form_quantity(allow_negative=True)
            reason = _form_text("reason", "Reason", 160)
            current = next(
                (row for row in inventory_summary(load_store()) if row["item"].casefold() == item.casefold()),
                None,
            )
            if quantity < 0 and (current is None or current["available"] < abs(quantity)):
                raise ValueError("An adjustment cannot reduce stock below zero.")
            store = load_store()
            store["adjustments"].append(
                {
                    "id": _new_id(),
                    "item": current["item"] if current else item,
                    "category": current["category"] if current else category,
                    "unit": current["unit"] if current else unit,
                    "quantity": quantity,
                    "reason": reason,
                    "date": date.today().isoformat(),
                    "created_at": datetime.now().isoformat(timespec="seconds"),
                }
            )
            save_store(store)
            flash("Inventory adjustment saved.", "success")
            return redirect(url_for("inventory"))
        except ValueError as error:
            flash(str(error), "danger")
    items = inventory_summary(load_store())
    query = request.args.get("q", "").strip().casefold()
    category_filter = request.args.get("category", "").strip().casefold()
    low_stock_only = request.args.get("low_stock") == "1"
    items = [
        row for row in items
        if (not query or query in row["item"].casefold())
        and (not category_filter or category_filter == row["category"].casefold())
        and (not low_stock_only or row["low_stock"])
    ]
    categories = sorted({row["category"] for row in inventory_summary(load_store())})
    return render_template(
        "inventory.html",
        inventory=items,
        categories=categories,
        query=request.args.get("q", ""),
        selected_category=request.args.get("category", ""),
        low_stock_only=low_stock_only,
    )


@app.route("/distributions", methods=["GET", "POST"])
def distributions():
    if request.method == "POST":
        try:
            item = _form_text("item", "Item name")
            recipient = _form_text("recipient", "Recipient", 100)
            quantity = _form_quantity()
            notes = request.form.get("notes", "").strip()
            if len(notes) > 500:
                raise ValueError("Notes must be 500 characters or fewer.")
            store = load_store()
            current = next(
                (row for row in inventory_summary(store) if row["item"].casefold() == item.casefold()),
                None,
            )
            if current is None:
                raise ValueError("Select an item that exists in inventory.")
            if quantity > current["available"]:
                raise ValueError(f"Only {current['available']} {current['unit']} of {current['item']} are available.")
            record = {
                "id": _new_id(),
                "item": current["item"],
                "quantity": quantity,
                "recipient": recipient,
                "date": _form_date(),
                "notes": notes,
                "created_at": datetime.now().isoformat(timespec="seconds"),
            }
            store["distributions"].append(record)
            save_store(store)
            flash(f"Distribution of {quantity} {current['unit']} of {current['item']} recorded.", "success")
            return redirect(url_for("distributions"))
        except ValueError as error:
            flash(str(error), "danger")
    store = load_store()
    records = sorted(store["distributions"], key=lambda row: (row["date"], row["created_at"]), reverse=True)
    query = request.args.get("q", "").strip().casefold()
    records = [
        row for row in records
        if not query or query in " ".join(
            str(row.get(key, "")) for key in ("item", "recipient", "notes")
        ).casefold()
    ]
    return render_template(
        "distributions.html",
        distributions=records,
        inventory=[row for row in inventory_summary(store) if row["available"] > 0],
        query=request.args.get("q", ""),
    )


@app.route("/export.csv")
def export_csv():
    store = load_store()
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["Record type", "Date", "Item", "Category", "Quantity", "Unit", "Donor / recipient", "Notes"])
    for row in store["donations"]:
        writer.writerow(["Donation", row["date"], row["item"], row["category"], row["quantity"], row["unit"], row["donor"], row["notes"]])
    for row in store["distributions"]:
        item = next((entry for entry in inventory_summary(store) if entry["item"] == row["item"]), {})
        writer.writerow(["Distribution", row["date"], row["item"], item.get("category", ""), row["quantity"], item.get("unit", ""), row["recipient"], row["notes"]])
    for row in store["adjustments"]:
        writer.writerow(["Adjustment", row["date"], row["item"], row["category"], row["quantity"], row["unit"], row["reason"], ""])
    response = make_response("\ufeff" + output.getvalue())
    response.headers["Content-Type"] = "text/csv; charset=utf-8"
    response.headers["Content-Disposition"] = "attachment; filename=donation-inventory.csv"
    return response


@app.errorhandler(500)
def handle_server_error(error):
    app.logger.error("Unhandled server error: %s", error)
    return render_template("error.html"), 500


if __name__ == "__main__":
    load_store()
    app.run(host="127.0.0.1", port=5000, debug=os.environ.get("FLASK_DEBUG") == "1")
