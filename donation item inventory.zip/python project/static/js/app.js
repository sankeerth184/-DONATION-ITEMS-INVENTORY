document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll(".needs-validation").forEach(function (form) {
    form.addEventListener("submit", function (event) {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add("was-validated");
    });
  });

  var canvas = document.getElementById("categoryChart");
  if (canvas && window.kindredChartData && window.Chart) {
    new Chart(canvas, {
      type: "bar",
      data: {
        labels: window.kindredChartData.labels,
        datasets: [{
          label: "Available items",
          data: window.kindredChartData.values,
          backgroundColor: ["#6e5cdb", "#43b798", "#f0a568", "#7d9bea", "#e7869a", "#b28add", "#65b9cc"],
          borderRadius: 7,
          borderSkipped: false,
          maxBarThickness: 38
        }]
      },
      options: {
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: { backgroundColor: "#202a38", padding: 11, displayColors: false }
        },
        scales: {
          x: { grid: { display: false }, border: { display: false }, ticks: { color: "#8993a2", font: { family: "DM Sans" } } },
          y: { beginAtZero: true, grid: { color: "#f0f2f5" }, border: { display: false }, ticks: { color: "#8993a2", precision: 0, font: { family: "DM Sans" } } }
        }
      }
    });
  }
});
